package com.uxpsystems.assignement.controller;

import com.uxpsystems.assignement.models.User;
import com.uxpsystems.assignement.service.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserController {

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/user/add")
    public String createUser(@RequestBody User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userDetailsService.addUser(user);
    }

    @PutMapping("/user/update/{id}")
    public String updateUserByAdmin(@PathVariable("id") long id, @RequestBody User user){
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userDetailsService.updateUser(id,user);
    }
}
