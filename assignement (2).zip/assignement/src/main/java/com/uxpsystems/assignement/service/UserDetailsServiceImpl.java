package com.uxpsystems.assignement.service;


import com.uxpsystems.assignement.dao.UserRepository;
import com.uxpsystems.assignement.models.UserPrincipal;
import com.uxpsystems.assignement.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    public UserDetailsServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {
        User user = userRepository.findUserByUsername(username);

        if (user == null) {
            throw new UsernameNotFoundException("Could not find user");
        }

        return new UserPrincipal(user);
    }

    public String addUser(User user){
        userRepository.save(user);
                return "User Added Successfully!!!";
    }

    public Optional<User> getUserById(long id){
        return userRepository.findById(id);
    }

    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    public String updateUser(long id,User user){
      User existingUser = userRepository.findById(id).orElse(null);
      if(existingUser != null){
          existingUser.setUsername(user.getUsername());
          existingUser.setPassword(user.getPassword());
          existingUser.setRoles(user.getRoles());
          existingUser.setActive(user.isActive());
          userRepository.save(existingUser);
          return "User Updated";
      }
      return "User Not Found";
    }

    public String deleteUser(long id){
        userRepository.deleteById(id);
        return "User Deleted SuccessFully";
    }
}
