CREATE TABLE users(
user_id long(50) NOT NULL ,
username varchar(45) NOT NULL,
password varchar(255) NOT NULL,
active boolean DEFAULT false);