INSERT INTO `users` (user_id,username, password, active) VALUES (11,'patrick', '$2a$10$cTUErxQqYVyU2qmQGIktpup5chLEdhD2zpzNEyYqmxrHHJbSNDOG.',true);
INSERT INTO `users` (user_id,username, password, active) VALUES (12,'admin', '$2y$12$mBeFf.d9TG557uOQxYWgUeZstQ.dCKXxm5hLyaBorf7Gi76OW6OJO', true);
